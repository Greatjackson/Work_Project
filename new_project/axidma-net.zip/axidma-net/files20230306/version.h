#ifndef _VERSION_H_
#define _VERSION_H_

#define MODE "Debug"
#define PLATFORM "x64"
#define REDIRECT "to_term"
#define BUILD_TIME "2022-05-19 21:01:13"
#define WHO_BUILD "gang.liu"
#define BRANCH_NAME "* master"
#define COMMIT_ID "0a7b23c8f522290272776d6b2863b0f0aaa11bc4"
extern void show_version(void);

#endif

